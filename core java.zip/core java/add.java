class add{

public static void main(String args[])
{
int a=2,b=4,c;
c=a+b;
System.out.println("add"+c);
}
}

class welcome
{
int var1=123;
static int var2=1234;
void m1()
{
System.out.pritnln("instance method of welcome class");
}
static void m2()
{
System.out.println("static method of welcome class");
}
public static void main(String args[]){
welcome.m2();
welcome wel=new welcome();
wel.m1();
System.out.println(wel.var1);
System.out.println(wel.var2);
}
}
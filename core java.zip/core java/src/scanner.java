import java.util.Scanner;

public class scanner {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the employee name");
	String a=sc.next();
	System.out.println("enter the employee id");
	int b=sc.nextInt();
	System.out.println("enter the employee salary");
	int c=sc.nextInt();
	
	System.out.println("enter the employee area");
	String d=sc.next();
	d+=sc.nextLine();
	System.out.println(d);
	
	System.out.println("enter the employee name"+a);
	System.out.println("enter the employee id"+b);
	System.out.println("enter the employee salary"+c);
	System.out.println("enter the employee area"+d);
	
	
}
}

import java.util.Scanner;

public class primenumber {
	public static void main(String args[])
	{ int n;
	Scanner u=new Scanner(System.in);
	Scanner input = null;
	n=input.nextInt();
	
	if(prime(n))
	{
		System.out.println(n+"is a prime number");
	}
	else
	{
		System.out.println(n+"is not  prime number");
	}}
	
	private static int nextInt() {
		// TODO Auto-generated method stub
		return 0;
	}
	static boolean prime(int n){
		
	
		for(int i=2;i<=(n/2);i++)
		{
			if(n%i!=0)
				return false;
		}
		return true;
	}
}


package Threads;
class Account 
{
	public int balance;
	public Account()
	{
		balance=5000;
	}
	public synchronized  void withdraw(int bal) 
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		balance=balance-bal;
		System.out.println("Amount withdrawn="+bal);
		System.out.println("remaining bal="+balance);
	}
	public  synchronized void deposit(int bal)
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		balance=balance+bal;
	
		System.out.println("Amount deposit="+bal);
		System.out.println("remaining bal="+balance);
	}
	public synchronized  void enquiry()
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		System.out.println("Available balance="+balance);
	}
}

class Transcation implements Runnable
{
   Account obj;
  
	public Transcation(Account a) {
	super();
	this.obj = a;
}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		obj.withdraw(500);
		obj.deposit(1000);
		obj.enquiry();
		
	}
	
}



public class ThreadAccount {
public static void main(String[] args)
{
	Account a=new Account();
	Transcation t=new Transcation(a);
	Thread t1=new Thread(t);
	Thread t2=new Thread(t);
	t1.start();
	t2.start();
	
}
}

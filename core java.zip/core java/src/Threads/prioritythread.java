package Threads;
class thread1 extends Thread
{public void run()
	{
	Thread.currentThread();
	
	for(int i=0;i<5;i++)
	{ 
		System.out.println(Thread.currentThread());
	System.out.println("child thread");
	}
	
}
	
}
public class prioritythread {
public static void main(String[] args)

{ Thread.currentThread().setPriority(Thread.MIN_PRIORITY);;
thread1 t=new thread1();
t.start();
for(int i=0;i<10;i++)
{ Thread.currentThread().setName("nandy");
System.out.println(Thread.currentThread().getPriority());
	System.out.println("parent thread");
}
	}
}

package Threads;
class First{
	public synchronized void display(String name) 
	{
		System.out.println("["+name);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}System.out.println("]");
	}
}
class Second extends Thread
{
	String name;
	First obj;
	public Second(String ename, First eobj) {
		
		this.name = ename;
		this.obj = eobj;
		this.start();
	}
	
	public void run()
	
	{
		obj.display(name);
	}
	
}
public class synchronizedEx {
public static void main(String[] args)
{First f=new First();
Second s=new Second("nandy",f);
Second s1=new Second("sam",f);
Second s2=new Second("pooja",f);
	
}
}

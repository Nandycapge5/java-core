
public class Encaps {
private int eid;
private String ename;
private int esal;
private int atmpin;
public int age;

public int getAtmpin() {
	return atmpin;
}
public void setAtmpin(int atmpin) {
	this.atmpin = atmpin;
}
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public int getEsal() {
	return esal;
}
public void setEsal(int esal) {
	this.esal = esal;
}
public static void main(String args[]){
	Encaps e=new Encaps();
	e.setEid(123);
	e.setEname("samvitha");
	e.setEsal(50000);
	e.setAtmpin(5678);
	System.out.println(e.getEid()); 
	System.out.println(e.getEname());
	System.out.println(e.getEsal());
}

}

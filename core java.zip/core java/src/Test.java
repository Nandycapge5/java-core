import sun.applet.Main;

public class Test {
	int a=12;
	static int b=122;
	void m1()
	{
		System.out.println("test class instance method");
	}
	static void m2()
	{
		System.out.println("test class static method");
	}
	
	public static void main(String[] args) {
		Test t=new Test();
		t.m1();
		Test.m2();
		System.out.println(t.a);
		System.out.println(Test.b);
		System.out.println("welcome to java");

	}

}
 
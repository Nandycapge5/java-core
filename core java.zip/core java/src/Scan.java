import java.util.Scanner;

public class Scan {
public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the first number for division");
	int fnum=sc.nextInt();
	System.out.println("enter the 2nd number for division");
	int snum=sc.nextInt();
	try{
	int divi=fnum/snum;
	System.out.println("division"+divi);
	}
	catch(ArithmeticException e)
	{
		System.out.println("dont enter 0 as denominator");
	}
	
	try{
		int a[]=new int[5];
		a[0]=1;
		a[5]=5;
	}
	catch(ArrayIndexOutOfBoundsException e){
		System.out.println("array index out of range");
	}
	try{
		int a1=10;
		int b=0;
		int c=a1/b;
	}
	catch(ArithmeticException e)
	{
		//system.out.pritnln("dont enter zero as denominator");
		//System.out.println(e);
		e.printStackTrace();
	//	System.out.println(e.getMeaasge());
		
	}
	
	System.out.println("remaining lines of code execution");
	sc.close();
}
}


public class condition {

	public static void main(String args[])
{ 
		int x=0;
		if(x)
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("hi");
		}
		}
}

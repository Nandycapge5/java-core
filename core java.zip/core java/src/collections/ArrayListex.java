package collections;

import java.util.ArrayList;

public class ArrayListex {
	public static void main(String[] args){
	ArrayList al=new ArrayList();
	al.add(1);
	al.add(2);
	al.add("nandy");
	al.add("nandy");
	al.add('a');
	System.out.println(al);
}

}

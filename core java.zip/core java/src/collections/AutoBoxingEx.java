package collections;

public class AutoBoxingEx {
	public static void main(String[] args)
	{
int a=10;
//boxing
Integer a1=new Integer(a);
a1.valueOf(a);
System.out.println(a1);
//auto boxing
Integer i1=a;
System.out.println("i1 value is :"+i1);
Integer i=new Integer(20);
//unboxing
int x=i.intValue();
System.out.println(x);
//auto boxing
int y=i;
}}

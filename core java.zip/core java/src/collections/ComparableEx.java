package collections;

public class ComparableEx {
	public static  class ComparatorEx {
		public static void main(String[] args)
		{
			
			System.out.println("a".compareTo("g"));
			System.out.println("f".compareTo("b"));
			System.out.println("z".compareTo("k"));
			System.out.println("a".equals("a"));
		}
		}


		/*Comparable :
			compareTo()
		//if obj1 has comes before obj2,so return -ve
		//if obj1 has comes after obj2,so return +ve
		//if obj1 and obj2 are equals,so return 0
		*/
}

package collections;

import java.util.Comparator;
import java.util.TreeSet;

public class ComparatorEx {
public static void main(String[] args)
{TreeSet ts=new TreeSet(new MyComaparator());
ts.add(12);
ts.add(78);
ts.add(25);
	
	System.out.println("set:"+ts);
	
}}
/*
private static TreeSet TreeSet(MyComaparator myComaparator) {
	// TODO Auto-generated method stub
	return null;
}*/

class MyComaparator implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		Integer i1=(Integer) o1;
		Integer i2=(Integer) o2;
		//return i2.compareTo(i1);
		if(i1<i2)
		{
			return +1;
		}
		else if(i1>i2)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	
	}
}


/*Comparable :
	compareTo()
//if obj1 has comes before obj2,so return +ve
//if obj1 has comes after obj2,so return -ve
//if obj1 and obj2 are equals,so return 0
*/
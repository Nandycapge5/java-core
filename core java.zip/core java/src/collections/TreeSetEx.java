package collections;


import java.util.TreeSet;

public class TreeSetEx {
	
		public static void main(String[] args){
		TreeSet lhs=new TreeSet();
		 //lhs.add(13);
		 //lhs.add(13);
		// lhs.add(1);
		// lhs.add(25);
		// lhs.add(85);
		 //lhs.add(56);
		// lhs.add(45);  
		 lhs.add("ant");
		 lhs.add("delotie");
		 lhs.add("amazon");
		 lhs.add(25);
		 lhs.add(85);
		 lhs.add(56);
		 lhs.add(45); 
		 System.out.println(lhs);
		}
		}
//homogeneous data is only
//sorting order
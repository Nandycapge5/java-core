package collections;

import java.util.ArrayList;
class Employee4
{
		int eid;
		String name;
		int sal;
	public Employee4(String ename, int eid,int esal) {
		
		this.name = ename;
		this.eid = eid;
		this.sal=esal;
	}
	@Override
	public String toString() {
		return "[eid=" + eid +"\n"+ " name=" + name +"\n"+ "sal=" + sal + "]";
	}
}
public class EmployeeArrayList {
	public static void main(String[] args){
		Employee4 e1=new Employee4("nandy",20,10000);
		Employee4 e2=new Employee4("samvi",50,20000);
		Employee4 e3=new Employee4("poochi",45,25000);
		Employee4 e4=new Employee4("menaka",78,30000);
		
		ArrayList al=new ArrayList();
		al.add(e1);
		al.add(e2);
		al.add(e3);
		al.add(e4);
		System.out.println(al);
	}
}

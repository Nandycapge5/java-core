package collections;

import java.util.Comparator;
import java.util.TreeSet;

class Employee3 implements Comparable
{
String name;
int eid;
public Employee3(String ename, int eid) {
	
	this.name = ename;
	this.eid = eid;
}

public String toString() {
	return name+""+eid;
	// TODO Auto-generated constructor stub
}
@Override
public int compareTo(Object o) {
	// TODO Auto-generated method stub
	int eid1=this.eid;
	Employee3 e=(Employee3) o;
	int eid2=e.eid;
	if(eid1<eid2)
	
		{
		return +1;
		}
	else if(eid1>eid2){
		return -1;
	}
	else
	return 0;
}

	}
	class Mycomparator3 implements Comparator{

		@Override
		public int compare(Object o1, Object o2) {
			// TODO Auto-generated method stub
			Employee3 e1=(Employee3) o1;
			Employee3 e2=(Employee3) o2;
			String s1=e1.name;
			String s2=e2.name;
			return s1.compareTo(s2);
			
		}
		}

public class ComparableComparatorEx {
public static void main(String[] args)
{Employee3 e1=new Employee3("nandy",20);
Employee3 e2=new Employee3("sam",50);
Employee3 e3=new Employee3("pooja",45);
Employee3 e4=new Employee3("menaka",78);
TreeSet ts=new TreeSet();
ts.add(e1);
ts.add(e2);
ts.add(e3);
ts.add(e4);
System.out.println(ts);//based in ids
TreeSet t=new TreeSet(new Mycomparator3());
t.add(e1);
t.add(e2);
t.add(e3);
t.add(e4);
System.out.println(t);
}
}


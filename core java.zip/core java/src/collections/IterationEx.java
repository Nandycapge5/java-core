package collections;

import java.util.ArrayList;
import java.util.Iterator;

public class IterationEx {
public static void main(String[] args)
{ArrayList al=new ArrayList();
al.add("sam");
al.add("prithiv");
al.add("nandy");
al.add("nandy");
al.add("krishna");
System.out.println(al);

Iterator itr=al.iterator();
while(itr.hasNext())
{ String name=(String) itr.next();
if(name.equals("nandy"))
	{ itr.remove();
	
	}
 else
{System.out.println(name);
	
}
}}
}
	


package Queue;

import java.util.Iterator;
import java.util.PriorityQueue;

public class priorityQueueEx {
public static void main(String[] args)
{
	PriorityQueue<String> p=new PriorityQueue<String>();
	p.offer("a");
	p.offer("b");
	p.offer("c");
	p.offer("d");
	System.out.println(p);
	System.out.println(p.element());//head of the queue
	System.out.println(p.peek());//Retrieves, but does not remove, 
	//the head of this queue,or returns null if this queue is empty.
System.out.println(p.poll());

System.out.println("head"+"\t"+p.remove());//remove head of the queue
System.out.println(p);
System.out.println("iterating the queue elements");
Iterator itr= p.iterator();

while(itr.hasNext())
{
	System.out.println(itr.next());
}
}
}

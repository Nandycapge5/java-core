package Map;


import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapEx {
	public static void main(String[] args){
		
	
	TreeMap <Integer,String>t1=new TreeMap <Integer,String>();
    
     t1.put(1, "nandy");
 	t1.put(2, "sam");
 	t1.put(3, "pooja");
 	t1.put(4, "menaka");
 	Set s=t1.entrySet();
 	
	
 	//Set s=t1.keySet();
 	Iterator itr=s.iterator();
 	
 	while(itr.hasNext())
 	{  
 		//System.out.println(entry.getvalue());
	System.out.println(itr.next());

}}
}
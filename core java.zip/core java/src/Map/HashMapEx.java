
package Map;

import java.util.HashMap;

public class HashMapEx {
public static void main(String[] args)
{
	HashMap<Integer,String> hm=new HashMap<Integer,String>();
	HashMap hm1=new HashMap();
	hm.put(1, "nandy");
	hm.put(2, "sam");
	hm.put(3, "pooja");
	hm.put(1, "menaka");
	hm1.put("magha", 4);
	//hm.putAll(hm1);//put all the entries fro hm in this map
	hm1.get(hm);//returns values associates with t he key k
	hm1.remove(hm);
	System.out.println(hm1);
	//System.out.println(hm.entrySet());
	//System.out.println(hm1);
}
}

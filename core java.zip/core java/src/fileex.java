
public class fileex {
File f=new Filr();
}

package fileio;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class BufferedStreamEx {
	public static void main(String args[]) throws IOException
	{ String filepath="buff.txt";
	//1.creating Stream objects
	FileOutputStream fos=new FileOutputStream(filepath);//2 bytes
	//2.pass stream object to bufferstream constructor
	BufferedOutputStream bos=new BufferedOutputStream(fos);
	String s="oracle.com";
	byte[] b=s.getBytes();
	bos.write(b);
	bos.flush();
//1.create stream objects
	FileInputStream fis=new FileInputStream(filepath);
	//2.pass stream object to bufferstream constructor
	BufferedInputStream bis=new BufferedInputStream(fis);
	int i;
	while((i=bis.read())!=-1)
	System.out.println((char)i);
	}



	}


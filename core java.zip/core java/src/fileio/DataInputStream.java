package fileio;
import java.io.*;
import java.io.DataOutputStream;
import java.io.FileInputStream;

import java.io.FileOutputStream;
import java.io.IOException;

public class DataInputStream {
public static void main(String args[]) throws IOException
{
	FileOutputStream fs=new FileOutputStream("data.txt");
	DataOutputStream dos=new DataOutputStream(fs);
	dos.writeInt(10);
dos.writeUTF("vineet");
DataInputStream dis=new DataInputStream(new FileInputStream("data.txt"));
System.out.println("Int :"+ dis.readInt());
System.out.println("Int :"+dis.readUTF());
}




}

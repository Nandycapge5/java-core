package fileio;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

 class bufferwriter {
	
	
	public static void main(String args[]) throws IOException
	{
		FileWriter fw=new FileWriter("cap1.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		
	bw.write(97);
	bw.newLine();
	
	char [] ch1={'a','b','c'};
	bw.write(ch1);
	bw.newLine();
	
	bw.write("welcome");
	bw.newLine();
	bw.write("to ibm");
	bw.flush();
	bw.close();
	fw.close();
	}
	}


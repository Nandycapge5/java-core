package fileio;


import java.util.Scanner;

public class login {
public static void main(String args[]) 
{ 
Scanner sc=new Scanner(System.in);
System.out.println("enter the login id");
String username = sc.next();
	System.out.println("enter the password");
  String password=sc.next();
  if(username.equals("capgemini")&&password.equals("capgemini"))

  {
	  System.out.println("success");
  }
else
	{
	System.out.println("error");
	}
}
}



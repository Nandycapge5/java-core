package fileio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Scanner;

 public class login1 
 {
	public static void main(String args[]) throws IOException 
	{
		System.out.println("enter the login id");
	
	Scanner sc=new Scanner(System.in);

	String username = sc.next();
		System.out.println("enter the password");
	  String password=sc.next();
	  FileReader fr=new FileReader("abc3.txt");
	  BufferedReader bf=new  BufferedReader(fr);
	  String uname=bf.readLine();
	  String pass=bf.readLine();
	  String line=bf.readLine();
	  
	 for(;line!=null;)
	 { line=bf.readLine();
	  if(username.equals(uname)&&password.equals(pass))

	  {
		  System.out.println("success");
	  }
	else
		{
		System.out.println("error");
		} line=bf.readLine();
	  }

 }}

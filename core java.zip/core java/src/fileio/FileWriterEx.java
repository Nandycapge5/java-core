package fileio;

import java.io.FileWriter;
import java.io.IOException;

class FileWriterEx {
public static void main(String args[]) throws IOException
{
	FileWriter fw=new FileWriter("cap1.txt");
fw.write(97);
fw.write("sandeep \n intelect");
fw.write("\n");
char [] ch1={'a','b','c'};
fw.write(ch1);
fw.write("\n");
fw.flush();
fw.close();
}
}

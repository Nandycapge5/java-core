package fileio;

import java.io.File;
import java.io.IOException;

public class File1 {
public static void main(String args[]) throws IOException

{File f=new File("myfolder/myfolder2/myfolder/myfile.txt");
f.getParentFile().mkdirs();
f.createNewFile();
System.out.println("done"+f.getAbsolutePath());
}
}

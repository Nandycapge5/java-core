package fileio;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.Serializable;
class encap implements Serializable
{
	private int empid;
	private String name;
	transient private int esal;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int esal) {
		this.esal = esal;
	}
}
public class Serialization {
	public static void main(String args[]) throws IOException
	{
		encap e=new encap();
		e.setEmpid(123);
		e.setName("nandhini");
		e.setEsal(10000);
		FileOutputStream fos=new FileOutputStream("seri.txt");
		ObjectOutputStream os=new ObjectOutputStream(fos);
		os.writeObject(e);
		System.out.println("success");}
}

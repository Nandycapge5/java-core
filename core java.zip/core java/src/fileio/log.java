package fileio;

import java.io.File;
import java.io.IOException;

public class log {
	public static void main(String args[]) throws IOException
	{
	File f=new File("log1.txt");
	
	f.createNewFile();
	

	}}

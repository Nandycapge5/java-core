package fileio;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;

public class deserialization {
public static void main(String args[]) throws IOException, ClassNotFoundException

{ FileInputStream fis=new FileInputStream("seri.txt");

ObjectInputStream ois=new ObjectInputStream(fis) ;
encap e=(encap)ois.readObject();

System.out.println(e.getEmpid());
System.out.println(e.getName());
System.out.println(e.getEsal());
}
}
	
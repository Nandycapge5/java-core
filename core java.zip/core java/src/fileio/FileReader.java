
package fileio;
import java.io.*;
import java.io.IOException;

class FileReader {

public FileReader(String string) {
		// TODO Auto-generated constructor stub
	}

public static void main(String args[]) throws IOException 
{
	FileReader fr1=new FileReader("cap.txt");
	int i=fr1.read();
	while(i!=1)
	{
		System.out.println((char)i);
	i=fr1.read();
	
	}
	
}

private int read() {
	// TODO Auto-generated method stub
	return 0;
}

}

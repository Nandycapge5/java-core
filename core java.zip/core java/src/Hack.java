import java.awt.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Scanner;

class student
{
	private int id;
	private String name;
	private double cgpa;
	public student(int id, String name, double cgpa) {
		this.id = id;
		this.name = name;
		this.cgpa = cgpa;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCgpa() {
		return cgpa;
	}
	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}
	
}
public class Hack {
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int testcases=Integer.parseInt(sc.nextLine());
		java.util.List<student> studentlist=new ArrayList<student>();
		while(testcases>0){
			int id=sc.nextInt();
			String name=sc.next();
			double cgpa=sc.nextDouble();
			String fname;
			student st=new student(id,fname,cgpa);
			
			studentlist.add(st);
			testcases--;
		Object student;
		Collection.sort(studentlist,Comparator.thenComparingDouble(student::getCgpa
				()).reversed().thencomparing(student::getname));
		for(student st1: studentlist)
		{
			System.out.println (st1.getName());
			
			
		}
	}

	}
}

public class Increasingnumber {
 boolean checkNumber(int number)
{ int sum=0,rem;
	while(number>0)
	{ 
		rem=number%10;
		if(rem>sum){
		sum=sum+(rem);
		number=number/10;
		}
		else
		{
			return true;
		}
	}
	return false;
	
	}
	
	

public static void  main(String args[]){
	Increasingnumber i=new Increasingnumber();
	i.checkNumber(123);
}
}

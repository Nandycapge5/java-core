import java.util.Scanner;
public class Power {
	private static boolean checkNumber(int n){
		if (n % 2 != 0) {
		      return false;
		    }
		else {

		      for (int i = 0; i <= n; i++) {

		        if (Math.pow(2, i) == n) 
		        	return true;
		      }
		    }
		    return false;
		  }
	public static void main(String[] args) {
   Power p=new Power();
	System.out.println("enter the number");    
   Scanner in = new Scanner(System.in);
	    int n = in.nextInt();
	    
	    
	    if (checkNumber(n)) {
	      
	      System.out.println(n+"power of two");
	    } else {
	    	 System.out.println(n+"not power of two");
	    }
	    
	    System.out.println(p.checkNumber(n));
	  }
	}


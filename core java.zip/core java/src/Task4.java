
public class Task4 {
	 
	    public static void main(String[] args) {
	        String s1="Sam from cbe";
	        String s2="sam";
	        System.out.println(s1.endsWith(s2));
	    }

	 

	}


package labassignment;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class lab3Secondsmallest {
	
	int getSecondSmallest(int[] a){
		Arrays.sort(a);
		return a[1];
	}
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the aray size");
	int size=Integer.parseInt(sc.nextLine());
	System.out.println("enter the array elements:");
	int [] a=new int[size];

	for(int i=0;i<size;i++)
	{
		a[i]=sc.nextInt();
		
	}
	sc.close();
	lab3Secondsmallest s=new lab3Secondsmallest();
	System.out.println(s.getSecondSmallest(a));
}
}

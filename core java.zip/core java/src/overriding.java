class parent{
	 void m1()
	{
		System.out.println("parent class m1 method");
	}
	 void m2(){
		System.out.println("parent class m2 method");
	}
}
class child extends parent
{
	void m1()
	{
		System.out.println("method 3");
	}
		void m4()
		{
			System.out.println("method4");
		}
}
public class overriding extends child {
	public static void main(String args[])
	{ 
		overriding o=new overriding();
		o.m1();
		o.m4();
		o.m2();
	}
}









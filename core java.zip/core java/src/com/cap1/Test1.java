package com.cap1;

import com.cap.Test;

public class Test1 extends Test {
public static void main(String args[]){
	
	Test1 n=new Test1();
	System.out.println(n.eid);
	n.m1();
}
}
